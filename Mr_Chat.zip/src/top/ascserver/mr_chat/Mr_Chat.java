package top.ascserver.mr_chat;

import cn.nukkit.Player;
import cn.nukkit.event.EventHandler;
import cn.nukkit.event.Listener;
import cn.nukkit.event.player.PlayerChatEvent;
import cn.nukkit.plugin.PluginBase;

import java.util.Date;

/**
 * Created by ZERO on 2017/1/2.
 */
public class Mr_Chat extends PluginBase implements Listener{
    private String QX = "管理员";
    private String GM = "生存模式";
    public void onEnable(){
        saveResource("config.yml");
        this.getServer().getPluginManager().registerEvents(this,this);
        this.getServer().getLogger().info("插件正在加载，作者Mr_sky，贴吧ID贱哥啊哈哈");
    }
    public void onDisable(){
        this.getServer().getLogger().info("插件正在卸载!");
    }
    @EventHandler
    public void onPlayerChat(PlayerChatEvent event){
        event.setCancelled();
        Player player = event.getPlayer();
        String playername = player.getName();
        String xueliang = String.valueOf(player.getHealth());
        String zuidaxueliang = String.valueOf(player.getMaxHealth());
        if (player.getGamemode() == 0)
            this.GM = String.valueOf(getConfig().get("生存模式"));
        if (player.getGamemode() == 1)
            this.GM = String.valueOf(getConfig().get("创造模式"));
        if (player.getGamemode() == 2)
            this.GM = String.valueOf(getConfig().get("冒险模式"));
        if (player.getGamemode() == 3)
            this.GM = String.valueOf(getConfig().get("旁观模式"));
        if (player.isOp())
            this.QX = String.valueOf(getConfig().get("OP"));
        if (!player.isOp())
            this.QX = String.valueOf(getConfig().get("玩家"));
        String msg = event.getMessage();
        String level = player.getLevel().getName();
        String geshi = getConfig().get("格式").toString();
        String levelname = geshi.replace("{level}",level);
        String GMname = levelname.replace("{GM}",GM);
        String QXname = GMname.replace("{QX}",QX);
        String Timename = QXname.replace("{time}",onCurrentTime());
        String playern = Timename.replace("{name}",playername);
        String msgname = playern.replace("{msg}",msg);
        this.getServer().broadcastMessage(msgname);
    }
    public String onCurrentTime() {
        Date time = new Date();
        int hours = time.getHours();
        int minutes = time.getMinutes();
        int seconds = time.getSeconds();
        return hours  + ":"  + minutes  + ":" + seconds;
    }
}
